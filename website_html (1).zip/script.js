
document.addEventListener('DOMContentLoaded', () => {
    // Holographic effect for Savanroar on Pokedex page
    const savanroarElement = document.getElementById('savanroar-final-form');
    if (savanroarElement) {
        savanroarElement.classList.add('holographic-effect');
    }

    // Highlight active navigation link
    const currentPath = window.location.pathname.split('/').pop();
    const navLinks = document.querySelectorAll('nav ul li a');

    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active-nav');
        }
    });
});
